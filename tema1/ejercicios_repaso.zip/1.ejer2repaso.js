let num = 10;
const singular = "limón";
const plural = "limones";

for (let i = 1; i < num; i++) {
    if (i === 1) {
        console.log(`${i} limón y medio limón`);
    } else {
        console.log(`${i} limones y medio limón`);
    }
}
console.log(`¡¡¡Y ${num} LIMONES Y MEDIO LIMÓN!!!`);